Windows 32bit
1.Type make.bat on cmd  then you can get your hostname(you can use hostname instead of ip address)
2.Type chat_server.exe <Port Number>
3.Type chat_writer.exe <IP Address> <Port Number> <Nickname>
4.Type chat_browser.exe <IP Address> <Port Number>
5.To quit server on writer, type quit

Linux
1.Type makefile on bash
2.Type ./ chat_server <Port Number>
3.Type ./ chat_writer <IP Address> <Port Number> <Nickname>
4.Type ./ chat_browser <IP Address> <Port Number>
5.To quit server on writer, type quit
